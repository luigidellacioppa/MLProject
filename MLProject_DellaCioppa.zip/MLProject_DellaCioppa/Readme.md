# Heart Disease Classification
Heart Disease Classification to predict the onset of Heart Disease based on diagnostic measures. 

## Data
Heart Disease Data Set from UCI data repository

The data for the project are originally from the https://www.kaggle.com/datasets/redwankarimsony/heart-disease-data

## Pre-requisites
The project was developed using python 3.8 with the following packages:

- Pandas
- Numpy
- Scikit-learn
- Pandas-profiling
- Joblib
- Matplotlib 
- Seaborn

Installation with pip:

```bash
pip install -r requirements.txt
```